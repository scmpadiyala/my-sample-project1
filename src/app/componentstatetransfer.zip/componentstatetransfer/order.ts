export class OrderInfo {
  orderName;
  orderNo;
  orderStatus;
}
