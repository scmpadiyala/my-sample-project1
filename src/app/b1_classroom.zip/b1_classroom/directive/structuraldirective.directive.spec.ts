import { StructuraldirectiveDirective } from './structuraldirective.directive';

describe('StructuraldirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new StructuraldirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
