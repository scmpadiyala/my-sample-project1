import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simplestyle',
  templateUrl: './simplestyle.component.html',
  styleUrls: ['./simplestyle.component.css']
})
export class SimplestyleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
