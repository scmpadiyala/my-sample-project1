import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simplestyle2',
  templateUrl: './simplestyle2.component.html',
  styles: []
})
export class Simplestyle2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
